import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Scanner;
public class Ben extends JFrame
{
    private static final int FRAME_WIDTH = 250;
    private static final int FRAME_HEIGHT = 200;
    private File userData;
    static int ownerField;
    static int platformField;
    static JTextField userNameField;
    static JTextField passwordField;
    String[] options = new String[] {"Exit","PlayStation", "Xbox", "Nintendo Switch"};
    public Ben() throws FileNotFoundException
    {
        createComponents();
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
    }
    private void createComponents() throws FileNotFoundException
    {
        ownerField = JOptionPane.showConfirmDialog(null,"Are you owner?\n Click yes to log in","Check Owner", JOptionPane.YES_NO_OPTION);
        userNameField = new JTextField(10);
        passwordField = new JTextField(10);
        JLabel ownerLabel = new JLabel("Owner");
        JLabel userNameLabel = new JLabel("User Name");
        JLabel passwordLabel = new JLabel("Password");
        JButton loginButton = new JButton("Login");
        JButton exitButton = new JButton("Exit");
        JButton selectPlatformButton = new JButton("Select Platform");
        JPanel panel = new JPanel();
        if (ownerField == JOptionPane.NO_OPTION) {
            platformField = JOptionPane.showOptionDialog(null,"Choose platform","Welcome to our store",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
        } else {
        panel.add(userNameField);
        panel.add(userNameLabel);
        panel.add(passwordField);
        panel.add(passwordLabel);
        panel.add(loginButton);
        panel.add(exitButton);
        add(panel);
        ActionListener exitListener = new ClickListener1();
        ActionListener loginListener = new ClickListener2();
        exitButton.addActionListener(exitListener);
        loginButton.addActionListener(loginListener);}
    }
    public static class ClickListener1 implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            System.exit(0);
        }
    }
    public static class ClickListener2 implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            int count = 0;
            File inputFile = new File("USERDATA.txt");
            String userNameInput = userNameField.getText();
            String passwordInput = passwordField.getText();
            try {
                Scanner in = new Scanner(new File("USERDATA.txt"));
                while (in.hasNextLine())
                {
                    String s = in.nextLine();
                    String[] sArray = s.split(",");
                    if (userNameInput.equals(sArray[0]) && passwordInput.equals(sArray[1]))
                    {
                        count += 1;
                    }

                }
                if (count > 0)
                {
                    JOptionPane.showMessageDialog(null,
                            "Login Successful", "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else
                {
                    JOptionPane.showMessageDialog(null,
                            "Invalid Username / Password Combo", "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
                in.close();
            } catch (FileNotFoundException e) {
                JOptionPane.showMessageDialog(null,
                        "User Database Not Found", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}