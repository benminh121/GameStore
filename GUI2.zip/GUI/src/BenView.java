import javax.swing.JFrame;
import java.io.*;
public class BenView
{
    public static void main(String[] args) throws FileNotFoundException
    {
        JFrame frame = new Ben();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}